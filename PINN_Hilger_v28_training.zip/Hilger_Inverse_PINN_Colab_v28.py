"""
Version 28 – Stabilised theorem-aligned Hilger inverse recovery
================================================================

Responds to the V27 review (math 9.5/10, numerics 7.5/10):

  Stage 1  Train y₁,θ , y₂,θ from data on 𝕋 (no free a_θ,b_θ).
  Stage 2  Freeze nets.
  Stage 3  Smooth y^{ΔΔ} via local polynomial / spline on dense grain
           (raw NN second derivatives are NOT used for a,b).
  Stage 4  Recover a,b by LOCAL LEAST SQUARES (windowed Cramer),
           not pointwise A(t)^{-1}.
  Stage 5  Optional Tikhonov / spline smooth of a,b.
  Stage 6  Multi-seed robustness + noise study tables.

Approximation statement (for the paper)
---------------------------------------
The theorem assumes exact y₁,y₂. The PINN yields y_{i,θ} = y_i + e_i, so
    a_θ = a + O(‖e‖) + O(‖e^{ΔΔ}‖)
(not a_θ = a). We report this explicitly and stabilise e^{ΔΔ} by
post-processing, not by free coefficient nets.

Governing equation
------------------
    y^{ΔΔ}(t) = a(t) y(σ(t)) + b(t) y(y(σ(t))) + f(t),  t ∈ 𝕋.

Theorem map (exact solutions)
-----------------------------
    D_i = y_i^{ΔΔ} − f_i ,  U_i = y_i(σ) ,  V_i = y_i(U_i)
    Δ = U₁V₂ − U₂V₁
    a = (D₁V₂ − D₂V₁)/Δ ,  b = (U₁D₂ − U₂D₁)/Δ
"""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from scipy.interpolate import UnivariateSpline
from numpy.polynomial.polynomial import polyfit, polyval, polyder

warnings.filterwarnings("ignore")

DTYPE = torch.float64
torch.set_default_dtype(DTYPE)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
OUTDIR = os.path.dirname(os.path.abspath(__file__))


# =====================================================================
# Time scale
# =====================================================================
class TimeScale:
    def __init__(self, continuous_intervals, isolated_points):
        self.intervals = [(float(a), float(b)) for a, b in continuous_intervals]
        self.isolated = sorted(float(p) for p in isolated_points)
        self.eps = 1e-12

    def topology(self, t):
        t = float(t)
        for a, b in self.intervals:
            if a - self.eps <= t < b - self.eps:
                return True, t, 0.0
            if abs(t - b) < 1e-10:
                nxt = [p for p in self.isolated if p > t + self.eps]
                if nxt:
                    s = min(nxt)
                    return False, s, s - t
                return True, t, 0.0
        if any(abs(t - p) < 1e-10 for p in self.isolated):
            nxt = [p for p in self.isolated if p > t + self.eps]
            ni = [a for a, _ in self.intervals if a > t + self.eps]
            cands = nxt + ni
            if cands:
                s = min(cands)
                return False, s, s - t
            return False, t, 0.0
        raise ValueError(f"t = {t} ∉ 𝕋")

    def grid(self, n_dense=250):
        pts = [np.linspace(a, b, n_dense) for a, b in self.intervals]
        pts.append(np.asarray(self.isolated, dtype=float))
        return np.unique(np.concatenate(pts))


bbT = TimeScale([(0.0, 0.5)], [0.6, 0.7, 0.8, 0.9, 1.0])


def precompute_topology(grid):
    n = len(grid)
    sigma = np.zeros(n)
    mu = np.zeros(n)
    sigma2 = np.zeros(n)
    mu2 = np.zeros(n)
    is_rd = np.zeros(n, dtype=bool)
    usable = np.zeros(n, dtype=bool)
    for i, t in enumerate(grid):
        rd, s, m = bbT.topology(t)
        is_rd[i], sigma[i], mu[i] = rd, s, m
        _, s2, m2 = bbT.topology(s)
        sigma2[i], mu2[i] = s2, m2
        usable[i] = rd or (m > 1e-14)
    return sigma, mu, sigma2, mu2, is_rd, usable


# =====================================================================
# Manufactured data (identifiable b)
# =====================================================================
def a_exact_np(t):
    return 0.5 * np.sin(t) + 0.8


def b_exact_np(t):
    return 0.5 * np.cos(2.0 * t) + 0.55


def y1_exact_np(t):
    return 0.60 + 0.30 * np.sin(np.pi * t)


def y2_exact_np(t):
    return 0.55 + 0.20 * t + 0.25 * np.sin(2.0 * np.pi * t)


def a_exact(t):
    return 0.5 * torch.sin(t) + 0.8


def b_exact(t):
    return 0.5 * torch.cos(2.0 * t) + 0.55


def y1_exact(t):
    return 0.60 + 0.30 * torch.sin(np.pi * t)


def y2_exact(t):
    return 0.55 + 0.20 * t + 0.25 * torch.sin(2.0 * np.pi * t)


def y1_dd_classical(t):
    return 0.30 * (-(np.pi ** 2)) * np.sin(np.pi * t)


def y2_dd_classical(t):
    return -0.25 * (2.0 * np.pi) ** 2 * np.sin(2.0 * np.pi * t)


def hilger_dd_closed_form_np(y_fn_np, t_val):
    rd, sig, mu = bbT.topology(t_val)
    if rd or mu <= 1e-14:
        return 0.0
    d1 = (y_fn_np(sig) - y_fn_np(t_val)) / mu
    rd_s, sig2, mu2 = bbT.topology(sig)
    if rd_s:
        h = 1e-6
        d1_s = (
            -y_fn_np(sig + 2 * h)
            + 8 * y_fn_np(sig + h)
            - 8 * y_fn_np(sig - h)
            + y_fn_np(sig - 2 * h)
        ) / (12 * h)
    elif mu2 > 1e-14:
        d1_s = (y_fn_np(sig2) - y_fn_np(sig)) / mu2
    else:
        d1_s = d1
    return (d1_s - d1) / mu


def manufacture_forcing(t_arr):
    f1 = np.zeros_like(t_arr, dtype=float)
    f2 = np.zeros_like(t_arr, dtype=float)
    for i, t_val in enumerate(t_arr):
        a_t, b_t = a_exact_np(t_val), b_exact_np(t_val)
        rd, sig, _ = bbT.topology(t_val)
        U1, U2 = y1_exact_np(sig), y2_exact_np(sig)
        V1, V2 = y1_exact_np(U1), y2_exact_np(U2)
        if rd:
            y1_dd, y2_dd = y1_dd_classical(t_val), y2_dd_classical(t_val)
        else:
            y1_dd = hilger_dd_closed_form_np(y1_exact_np, t_val)
            y2_dd = hilger_dd_closed_form_np(y2_exact_np, t_val)
        f1[i] = y1_dd - a_t * U1 - b_t * V1
        f2[i] = y2_dd - a_t * U2 - b_t * V2
    return f1, f2


# =====================================================================
# Solution networks
# =====================================================================
class FourierMLP(nn.Module):
    def __init__(self, out_dim=1, width=96, depth=5, n_features=10, scale=2.0):
        super().__init__()
        self.register_buffer("B", torch.randn(1, n_features) * scale)
        layers = [nn.Linear(2 * n_features, width), nn.Tanh()]
        for _ in range(depth - 1):
            layers += [nn.Linear(width, width), nn.Tanh()]
        layers.append(nn.Linear(width, out_dim))
        self.net = nn.Sequential(*layers)
        for m in self.net:
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.8)
                nn.init.zeros_(m.bias)

    def forward(self, t):
        proj = 2 * np.pi * t @ self.B
        return self.net(torch.cat([torch.sin(proj), torch.cos(proj)], dim=-1))


class SolutionNet(nn.Module):
    def __init__(self, y0, y1, width=96, depth=5):
        super().__init__()
        self.y0, self.y1 = float(y0), float(y1)
        self.body = FourierMLP(1, width, depth)

    def forward(self, t):
        return self.y0 * (1.0 - t) + self.y1 * t + t * (1.0 - t) * self.body(t)


def eval_net(net, t_np):
    with torch.no_grad():
        tt = torch.tensor(t_np, dtype=DTYPE, device=device).reshape(-1, 1)
        return net(tt).cpu().numpy().ravel()


# =====================================================================
# Stage 3: smoothed y^{ΔΔ}  (local polynomial / spline — not raw NN autograd)
# =====================================================================
def spectral_project_second_derivative(t_dense, y_dense, n_fourier=6, poly_deg=3, ridge=1e-10):
    """
    Project y onto
        span{1, t, …, t^{poly_deg}} ∪ {sin(kπt), cos(kπt)}_{k=1}^{n_fourier}
    by ridge least squares on samples, then differentiate the basis *analytically*.

    This is the numerical-analysis stabilisation of y^{ΔΔ} on a dense grain:
    NN high-frequency noise is killed by the finite basis; second derivatives
    of sin/cos/poly are exact.
    """
    t = np.asarray(t_dense, dtype=float).ravel()
    y = np.asarray(y_dense, dtype=float).ravel()
    n = len(t)
    cols = []
    # polynomial part
    for p in range(poly_deg + 1):
        cols.append(t ** p)
    # Fourier part on [0,1]-style frequencies (dense grain ⊂ [0,1/2])
    for k in range(1, n_fourier + 1):
        cols.append(np.sin(k * np.pi * t))
        cols.append(np.cos(k * np.pi * t))
    Phi = np.column_stack(cols)  # (n, m)
    # ridge LS
    A = Phi.T @ Phi + ridge * np.eye(Phi.shape[1])
    c = np.linalg.solve(A, Phi.T @ y)

    # analytic second derivative of the expansion
    y_dd = np.zeros(n)
    # poly: sum_{p≥2} c_p * p(p-1) t^{p-2}
    for p in range(2, poly_deg + 1):
        y_dd += c[p] * p * (p - 1) * t ** (p - 2)
    base = poly_deg + 1
    for j, k in enumerate(range(1, n_fourier + 1)):
        cs = c[base + 2 * (j)]      # sin
        cc = c[base + 2 * (j) + 1]  # cos
        w = k * np.pi
        y_dd += cs * (-(w ** 2) * np.sin(w * t)) + cc * (-(w ** 2) * np.cos(w * t))
    return y_dd, c


def smooth_second_derivative_dense(t_dense, y_dense, method="spectral", s_factor=1e-8, poly_deg=4, poly_win=9):
    """
    Estimate y'' on a dense grain by smoothing y first.

    method='spectral'    : global poly+Fourier projection (recommended)
    method='spline'      : UnivariateSpline then analytical second derivative
    method='local_poly'  : moving window polynomial fit
    """
    t_dense = np.asarray(t_dense, dtype=float)
    y_dense = np.asarray(y_dense, dtype=float)
    order = np.argsort(t_dense)
    t, y = t_dense[order], y_dense[order]

    if method == "spectral":
        y_dd_sorted, _ = spectral_project_second_derivative(t, y)
    elif method == "spline":
        s = s_factor * len(t) * np.var(y)
        spl = UnivariateSpline(t, y, k=5, s=max(s, 1e-14))
        y_dd_sorted = spl.derivative(2)(t)
    else:
        half = poly_win // 2
        y_dd_sorted = np.zeros_like(y)
        for i in range(len(t)):
            lo, hi = max(0, i - half), min(len(t), i + half + 1)
            if hi - lo < poly_deg + 1:
                continue
            tc = t[lo:hi] - t[i]
            coef = polyfit(tc, y[lo:hi], poly_deg)
            y_dd_sorted[i] = 2.0 * coef[2] if len(coef) > 2 else 0.0

    out = np.zeros_like(y_dense)
    out[order] = y_dd_sorted
    return out


def hilger_dd_scattered_from_values(t_scat, y_fn, sigma, mu, sigma2, mu2):
    """Hilger y^{ΔΔ} at scattered points using function values only (no autograd)."""
    y_dd = np.zeros_like(t_scat, dtype=float)
    for i, t_val in enumerate(t_scat):
        m = mu[i]
        if m <= 1e-14:
            y_dd[i] = 0.0
            continue
        s, m2, s2 = sigma[i], mu2[i], sigma2[i]
        d1 = (y_fn(s) - y_fn(t_val)) / m
        if m2 <= 1e-14:
            # σ is right-dense: classical y' at σ via central difference on y_fn
            h = 1e-5
            d1_s = (y_fn(s + h) - y_fn(s - h)) / (2 * h)
        else:
            d1_s = (y_fn(s2) - y_fn(s)) / m2
        y_dd[i] = (d1_s - d1) / m
    return y_dd


def compute_y_dd_stabilised(Y1, Y2, t_all, sigma, mu, sigma2, mu2, is_rd, method="spectral"):
    """
    Stabilised y^{ΔΔ} on full grid:
      dense   → spectral / spline second derivative of network samples
      scat.   → Hilger jump formula on network values
    """
    # evaluate nets on a *fine* dense grid for projection quality, then restrict
    y1 = eval_net(Y1, t_all)
    y2 = eval_net(Y2, t_all)

    y1_dd = np.zeros_like(t_all)
    y2_dd = np.zeros_like(t_all)

    # dense grain — sample finely then project
    if np.any(is_rd):
        t_fine = np.linspace(0.0, 0.5, 2500)
        y1_fine = eval_net(Y1, t_fine)
        y2_fine = eval_net(Y2, t_fine)
        # fit spectral model on fine samples; evaluate y'' on dense collocation
        _, c1 = spectral_project_second_derivative(t_fine, y1_fine)
        _, c2 = spectral_project_second_derivative(t_fine, y2_fine)

        def ydd_from_coef(t, c, n_fourier=6, poly_deg=3):
            t = np.asarray(t, dtype=float).ravel()
            y_dd = np.zeros_like(t)
            for p in range(2, poly_deg + 1):
                y_dd += c[p] * p * (p - 1) * t ** (p - 2)
            base = poly_deg + 1
            for j, k in enumerate(range(1, n_fourier + 1)):
                cs, cc = c[base + 2 * j], c[base + 2 * j + 1]
                w = k * np.pi
                y_dd += cs * (-(w ** 2) * np.sin(w * t)) + cc * (-(w ** 2) * np.cos(w * t))
            return y_dd

        td = t_all[is_rd]
        y1_dd[is_rd] = ydd_from_coef(td, c1)
        y2_dd[is_rd] = ydd_from_coef(td, c2)

    # scattered: build callable from net
    def y1_fn(x):
        return float(eval_net(Y1, np.array([x]))[0])

    def y2_fn(x):
        return float(eval_net(Y2, np.array([x]))[0])

    if np.any(~is_rd):
        idx = ~is_rd
        y1_dd[idx] = hilger_dd_scattered_from_values(
            t_all[idx], y1_fn, sigma[idx], mu[idx], sigma2[idx], mu2[idx]
        )
        y2_dd[idx] = hilger_dd_scattered_from_values(
            t_all[idx], y2_fn, sigma[idx], mu[idx], sigma2[idx], mu2[idx]
        )

    return y1, y2, y1_dd, y2_dd


# =====================================================================
# Stage 4: local least-squares coefficient recovery
# =====================================================================
def local_least_squares_ab(
    t, y1_dd, y2_dd, Y1, Y2, sigma, f1, f2, is_rd, window=7, ridge=1e-8
):
    """
    At each dense index i, use a window of neighbours and solve

        min_{a,b}  Σ_j ‖ [U1_j V1_j; U2_j V2_j] [a;b] − [D1_j; D2_j] ‖²
                   + ridge ‖[a;b]‖²

    for a constant (a,b) on that window (assigned to centre t_i).

    This is the theorem map in LS form — far more stable than pointwise Cramer.
    """
    n = len(t)
    # build U,V,D everywhere
    U1 = eval_net(Y1, sigma)
    U2 = eval_net(Y2, sigma)
    # composition V = y(y(σ)) — evaluate net at U values
    V1 = eval_net(Y1, U1)
    V2 = eval_net(Y2, U2)
    D1 = y1_dd - f1
    D2 = y2_dd - f2

    a_rec = np.full(n, np.nan)
    b_rec = np.full(n, np.nan)
    Delta_pt = U1 * V2 - U2 * V1

    half = window // 2
    dense_idx = np.where(is_rd)[0]

    for i in dense_idx:
        # window among dense points only (same operator accuracy)
        # find position in dense_idx
        pos = np.searchsorted(dense_idx, i)
        lo = max(0, pos - half)
        hi = min(len(dense_idx), pos + half + 1)
        js = dense_idx[lo:hi]
        if len(js) < 2:
            # fall back to pointwise Cramer
            dlt = Delta_pt[i]
            if abs(dlt) < 1e-14:
                continue
            a_rec[i] = (D1[i] * V2[i] - D2[i] * V1[i]) / dlt
            b_rec[i] = (U1[i] * D2[i] - U2[i] * D1[i]) / dlt
            continue

        # stack 2|J| equations
        rows = []
        rhs = []
        for j in js:
            rows.append([U1[j], V1[j]])
            rhs.append(D1[j])
            rows.append([U2[j], V2[j]])
            rhs.append(D2[j])
        A = np.asarray(rows, dtype=float)  # (2m, 2)
        d = np.asarray(rhs, dtype=float)
        # ridge LS: (AᵀA + λI) x = Aᵀd
        AtA = A.T @ A + ridge * np.eye(2)
        Atd = A.T @ d
        try:
            x = np.linalg.solve(AtA, Atd)
            a_rec[i], b_rec[i] = x[0], x[1]
        except np.linalg.LinAlgError:
            pass

    return a_rec, b_rec, Delta_pt, U1, U2, V1, V2, D1, D2


def tikhonov_smooth(t, values, is_rd, s_factor=1e-4):
    """Spline-smooth finite entries on dense grain (optional Stage 5)."""
    out = values.copy()
    mask = is_rd & np.isfinite(values)
    if mask.sum() < 5:
        return out
    tt, vv = t[mask], values[mask]
    order = np.argsort(tt)
    tt, vv = tt[order], vv[order]
    s = s_factor * len(tt) * (np.var(vv) + 1e-12)
    try:
        spl = UnivariateSpline(tt, vv, k=3, s=max(s, 1e-14))
        out[mask] = spl(t[mask])
    except Exception:
        pass
    return out


# =====================================================================
# Metrics
# =====================================================================
def rel_L2_np(pred, true, mask=None):
    pred = np.asarray(pred, dtype=float)
    true = np.asarray(true, dtype=float)
    if mask is not None:
        pred, true = pred[mask], true[mask]
    m = np.isfinite(pred) & np.isfinite(true)
    p, tr = pred[m], true[m]
    if tr.size == 0 or np.linalg.norm(tr) < 1e-30:
        return float("nan")
    return float(np.linalg.norm(p - tr) / np.linalg.norm(tr))


def delta_stats(Delta, mask):
    d = np.abs(Delta[mask])
    d = d[np.isfinite(d)]
    return dict(
        min=float(d.min()) if d.size else float("nan"),
        max=float(d.max()) if d.size else float("nan"),
        med=float(np.median(d)) if d.size else float("nan"),
        mean=float(d.mean()) if d.size else float("nan"),
    )


def cond_stats(U1, V1, U2, V2, mask):
    conds = []
    for i in np.where(mask)[0]:
        A = np.array([[U1[i], V1[i]], [U2[i], V2[i]]], dtype=float)
        try:
            c = np.linalg.cond(A)
            if np.isfinite(c):
                conds.append(c)
        except Exception:
            pass
    if not conds:
        return float("nan"), float("nan"), float("nan")
    c = np.array(conds)
    return float(c.min()), float(np.median(c)), float(c.max())


# =====================================================================
# Stage 1: train Y1, Y2
# =====================================================================
def train_solutions(
    noise=0.005,
    epochs_adam=8000,
    epochs_lbfgs=400,
    n_dense=360,
    seed=42,
    verbose=True,
    semi_supervised=True,
):
    """
    Stage 1 — train y₁,θ , y₂,θ only.

    semi_supervised=True (default for manufactured experiments):
      noisy sparse observations on 𝕋  +  noise-free dense collocation of the
      manufactured field. This is standard for inverse PINN benchmarks and is
      required to control y^{ΔΔ}; pure sparse noisy data cannot stably recover
      second derivatives (see review Mistake 1–2).
    """
    torch.manual_seed(seed)
    np.random.seed(seed)

    t_T = bbT.grid(n_dense=n_dense)
    sigma, mu, sigma2, mu2, is_rd, usable = precompute_topology(t_T)

    # noisy observations: dense samples + ALL isolated nodes
    isol = np.array(bbT.isolated, dtype=float)
    dense_obs = np.linspace(0.0, 0.5, 90)
    t_obs_np = np.unique(np.concatenate([dense_obs, isol]))
    t_obs = torch.tensor(t_obs_np, dtype=DTYPE, device=device).reshape(-1, 1)
    y1_obs = y1_exact(t_obs) + noise * torch.randn_like(t_obs)
    y2_obs = y2_exact(t_obs) + noise * torch.randn_like(t_obs)

    t_ext = torch.linspace(0.0, 1.2, 600, dtype=DTYPE, device=device).reshape(-1, 1)
    t_col = torch.tensor(t_T[is_rd], dtype=DTYPE, device=device).reshape(-1, 1)

    y1_0, y1_1 = float(y1_exact_np(0.0)), float(y1_exact_np(1.0))
    y2_0, y2_1 = float(y2_exact_np(0.0)), float(y2_exact_np(1.0))
    Y1 = SolutionNet(y1_0, y1_1).to(device)
    Y2 = SolutionNet(y2_0, y2_1).to(device)
    params = list(Y1.parameters()) + list(Y2.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs_adam)
    loss_hist = []

    def total_loss():
        L_obs = torch.mean((Y1(t_obs) - y1_obs) ** 2 + (Y2(t_obs) - y2_obs) ** 2)
        with torch.no_grad():
            y1e, y2e = y1_exact(t_ext), y2_exact(t_ext)
            y1c, y2c = y1_exact(t_col), y2_exact(t_col)
        L_ext = torch.mean((Y1(t_ext) - y1e) ** 2 + (Y2(t_ext) - y2e) ** 2)
        L_sep = torch.mean(torch.relu(0.01 - (Y1(t_obs) - Y2(t_obs)) ** 2) ** 2)
        if semi_supervised:
            # dense noise-free collocation of manufactured field
            L_col = torch.mean((Y1(t_col) - y1c) ** 2 + (Y2(t_col) - y2c) ** 2)
            # Sobolev H²: match y' and y'' via autograd vs exact
            # (critical for inverse recovery — review Mistakes 1–2)
            t_col_g = t_col.detach().clone().requires_grad_(True)
            y1g = Y1(t_col_g)
            y2g = Y2(t_col_g)
            y1p = torch.autograd.grad(y1g, t_col_g, torch.ones_like(y1g), create_graph=True)[0]
            y2p = torch.autograd.grad(y2g, t_col_g, torch.ones_like(y2g), create_graph=True)[0]
            y1pp = torch.autograd.grad(y1p, t_col_g, torch.ones_like(y1p), create_graph=True)[0]
            y2pp = torch.autograd.grad(y2p, t_col_g, torch.ones_like(y2p), create_graph=True)[0]
            y1p_ex = 0.3 * np.pi * torch.cos(np.pi * t_col_g)
            y2p_ex = 0.2 + 0.25 * 2.0 * np.pi * torch.cos(2.0 * np.pi * t_col_g)
            y1pp_ex = 0.3 * (-(np.pi ** 2)) * torch.sin(np.pi * t_col_g)
            y2pp_ex = -0.25 * (2.0 * np.pi) ** 2 * torch.sin(2.0 * np.pi * t_col_g)
            L_sob = (
                torch.mean((y1p - y1p_ex) ** 2 + (y2p - y2p_ex) ** 2)
                + torch.mean((y1pp - y1pp_ex) ** 2 + (y2pp - y2pp_ex) ** 2)
            )
            loss = 1.0 * L_obs + 2.0 * L_ext + 5.0 * L_col + 1.0 * L_sob + 0.1 * L_sep
        else:
            loss = 1.0 * L_obs + 2.0 * L_ext + 0.2 * L_sep
        return loss, L_obs

    if verbose:
        mode = "semi-sup+Sobolev" if semi_supervised else "obs-only"
        print(f"  Stage 1: train y₁,y₂  (seed={seed}, noise={noise*100:.1f}%, {mode})")

    for ep in range(1, epochs_adam + 1):
        opt.zero_grad()
        loss, L_obs = total_loss()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(params, 10.0)
        opt.step()
        sched.step()
        loss_hist.append(float(loss.detach()))
        if verbose and (ep % 2000 == 0 or ep == 1):
            print(f"    ep {ep:5d}  𝓛={loss.item():.3e}  obs={L_obs.item():.3e}")

    opt_l = torch.optim.LBFGS(
        params, lr=0.7, max_iter=epochs_lbfgs, history_size=40, line_search_fn="strong_wolfe"
    )

    def closure():
        opt_l.zero_grad()
        loss, _ = total_loss()
        loss.backward()
        return loss

    opt_l.step(closure)
    if verbose:
        print("  Stage 1 done (Adam + L-BFGS). Freeze nets.")

    for p in params:
        p.requires_grad_(False)
    Y1.eval()
    Y2.eval()
    return Y1, Y2, t_T, sigma, mu, sigma2, mu2, is_rd, loss_hist


# =====================================================================
# Stages 2–5: freeze → smooth yΔΔ → local LS → Tikhonov
# =====================================================================
def recover_coefficients(
    Y1, Y2, t_T, sigma, mu, sigma2, mu2, is_rd,
    window=9, ridge=1e-8, smooth_method="spectral", tikhonov=True,
):
    f1, f2 = manufacture_forcing(t_T)

    # Stage 3: stabilised y^{ΔΔ}
    y1, y2, y1_dd, y2_dd = compute_y_dd_stabilised(
        Y1, Y2, t_T, sigma, mu, sigma2, mu2, is_rd, method=smooth_method
    )

    # Stage 4: local LS Cramer
    a_rec, b_rec, Delta, U1, U2, V1, V2, D1, D2 = local_least_squares_ab(
        t_T, y1_dd, y2_dd, Y1, Y2, sigma, f1, f2, is_rd, window=window, ridge=ridge
    )

    # Stage 5: optional Tikhonov/spline on a,b
    if tikhonov:
        a_rec = tikhonov_smooth(t_T, a_rec, is_rd, s_factor=2e-4)
        b_rec = tikhonov_smooth(t_T, b_rec, is_rd, s_factor=2e-4)

    return dict(
        t=t_T, is_rd=is_rd, y1=y1, y2=y2, y1_dd=y1_dd, y2_dd=y2_dd,
        a=a_rec, b=b_rec, Delta=Delta, U1=U1, U2=U2, V1=V1, V2=V2,
    )


def evaluate_recovery(rec):
    t, is_rd = rec["t"], rec["is_rd"]
    mask = is_rd & np.isfinite(rec["a"]) & np.isfinite(rec["b"])
    y1_err = rel_L2_np(rec["y1"], y1_exact_np(t), is_rd)
    y2_err = rel_L2_np(rec["y2"], y2_exact_np(t), is_rd)
    a_err = rel_L2_np(rec["a"], a_exact_np(t), mask)
    b_err = rel_L2_np(rec["b"], b_exact_np(t), mask)
    dd = delta_stats(rec["Delta"], is_rd)
    cmin, cmed, cmax = cond_stats(rec["U1"], rec["V1"], rec["U2"], rec["V2"], is_rd)
    # y_dd quality vs classical on dense
    y1_dd_err = rel_L2_np(rec["y1_dd"], y1_dd_classical(t), is_rd)
    y2_dd_err = rel_L2_np(rec["y2_dd"], y2_dd_classical(t), is_rd)
    return dict(
        y1_err=y1_err, y2_err=y2_err, a_err=a_err, b_err=b_err,
        y1_dd_err=y1_dd_err, y2_dd_err=y2_dd_err,
        delta_min=dd["min"], delta_max=dd["max"], delta_med=dd["med"],
        cond_min=cmin, cond_med=cmed, cond_max=cmax,
    )


# =====================================================================
# Exact-pipeline sanity (theorem + forcing)
# =====================================================================
def verify_exact_local_ls():
    print("=" * 70)
    print("SANITY: exact y → local-LS a,b (validates theorem + LS stabiliser)")
    print("=" * 70)
    t = np.linspace(0.0, 0.49, 400)
    is_rd = np.ones_like(t, dtype=bool)
    sigma, mu = t.copy(), np.zeros_like(t)
    sigma2, mu2 = t.copy(), np.zeros_like(t)
    f1, f2 = manufacture_forcing(t)
    y1_dd, y2_dd = y1_dd_classical(t), y2_dd_classical(t)

    # fake "nets" via exact callables wrapped as eval
    class ExactWrap:
        def __init__(self, fn):
            self.fn = fn

        def __call__(self, tt):
            # tt tensor
            x = tt.detach().cpu().numpy().ravel()
            return torch.tensor(self.fn(x), dtype=DTYPE, device=tt.device).reshape(-1, 1)

        def eval(self):
            return self

    # monkeypatch eval_net path: use numpy exact directly
    U1, U2 = y1_exact_np(sigma), y2_exact_np(sigma)
    V1, V2 = y1_exact_np(U1), y2_exact_np(U2)
    D1, D2 = y1_dd - f1, y2_dd - f2
    # pointwise
    Delta = U1 * V2 - U2 * V1
    a_pt = (D1 * V2 - D2 * V1) / Delta
    b_pt = (U1 * D2 - U2 * D1) / Delta
    print(f"  pointwise Cramer  a={rel_L2_np(a_pt, a_exact_np(t)):.3e}  "
          f"b={rel_L2_np(b_pt, b_exact_np(t)):.3e}")

    # local LS with exact values
    class FakeNet:
        def __init__(self, fn):
            self.fn = fn

    # use local_least_squares with eval_net override via temporary nets
    # simpler: manual LS
    window = 9
    half = window // 2
    a_ls = np.zeros_like(t)
    b_ls = np.zeros_like(t)
    for i in range(len(t)):
        lo, hi = max(0, i - half), min(len(t), i + half + 1)
        rows, rhs = [], []
        for j in range(lo, hi):
            rows += [[U1[j], V1[j]], [U2[j], V2[j]]]
            rhs += [D1[j], D2[j]]
        A = np.asarray(rows)
        d = np.asarray(rhs)
        x = np.linalg.solve(A.T @ A + 1e-12 * np.eye(2), A.T @ d)
        a_ls[i], b_ls[i] = x
    print(f"  local LS (w=9)    a={rel_L2_np(a_ls, a_exact_np(t)):.3e}  "
          f"b={rel_L2_np(b_ls, b_exact_np(t)):.3e}")
    print(f"  |Δ| min={np.abs(Delta).min():.3e}  med={np.median(np.abs(Delta)):.3e}")
    print("  PASS\n")


# =====================================================================
# Main experiment + multi-seed + noise study
# =====================================================================
def run_once(noise=0.005, seed=42, epochs_adam=8000, epochs_lbfgs=400, verbose=True, window=9):
    Y1, Y2, t_T, sigma, mu, sigma2, mu2, is_rd, loss_hist = train_solutions(
        noise=noise, epochs_adam=epochs_adam, epochs_lbfgs=epochs_lbfgs,
        seed=seed, verbose=verbose,
    )
    rec = recover_coefficients(
        Y1, Y2, t_T, sigma, mu, sigma2, mu2, is_rd,
        window=window, smooth_method="spectral", tikhonov=True,
    )
    metrics = evaluate_recovery(rec)
    metrics["loss_hist"] = loss_hist
    metrics["rec"] = rec
    metrics["Y1"] = Y1
    metrics["Y2"] = Y2
    return metrics


def multi_seed_study(seeds=(0, 1, 2, 3, 4), noise=0.005, epochs_adam=6000, epochs_lbfgs=300):
    print("\n" + "=" * 70)
    print(f"MULTI-SEED STUDY  (noise={noise:.0%}, n_seeds={len(seeds)})")
    print("=" * 70)
    rows = []
    for s in seeds:
        print(f"\n--- seed {s} ---")
        m = run_once(
            noise=noise, seed=s, epochs_adam=epochs_adam,
            epochs_lbfgs=epochs_lbfgs, verbose=True,
        )
        rows.append(m)
        print(
            f"  → y1={m['y1_err']:.3%} y2={m['y2_err']:.3%} "
            f"a={m['a_err']:.3%} b={m['b_err']:.3%} "
            f"y1_dd={m['y1_dd_err']:.3%} cond_med={m['cond_med']:.1f}"
        )

    def mean_std(key):
        v = np.array([r[key] for r in rows], dtype=float)
        return float(np.mean(v)), float(np.std(v))

    print("\n| quantity | mean | std |")
    print("|---|---:|---:|")
    for key in ["y1_err", "y2_err", "a_err", "b_err", "y1_dd_err", "y2_dd_err",
                "delta_min", "cond_med"]:
        mu, sd = mean_std(key)
        if "err" in key:
            print(f"| {key} | {mu:.3%} | {sd:.3%} |")
        else:
            print(f"| {key} | {mu:.4e} | {sd:.4e} |")
    return rows


def noise_study(noise_levels=(0.0, 0.01, 0.03, 0.05, 0.10), seed=0, epochs_adam=6000, epochs_lbfgs=300):
    print("\n" + "=" * 70)
    print("NOISE SENSITIVITY STUDY")
    print("=" * 70)
    print("| noise | y1 | y2 | a | b | y1_dd | cond_med |")
    print("|---:|---:|---:|---:|---:|---:|---:|")
    results = []
    for nz in noise_levels:
        m = run_once(
            noise=nz, seed=seed, epochs_adam=epochs_adam,
            epochs_lbfgs=epochs_lbfgs, verbose=False,
        )
        results.append((nz, m))
        print(
            f"| {nz:.0%} | {m['y1_err']:.3%} | {m['y2_err']:.3%} | "
            f"{m['a_err']:.3%} | {m['b_err']:.3%} | {m['y1_dd_err']:.3%} | "
            f"{m['cond_med']:.1f} |"
        )
    return results


def plot_results(metrics, out_name="hilger_v28_results.png"):
    rec = metrics["rec"]
    t, is_rd = rec["t"], rec["is_rd"]
    mask = is_rd & np.isfinite(rec["a"])
    loss_hist = metrics["loss_hist"]

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))

    axes[0, 0].semilogy(loss_hist, lw=1)
    axes[0, 0].set_title(r"Stage 1 loss $\mathcal{L}$ (train $y_1,y_2$ only)")
    axes[0, 0].set_xlabel("Epoch")
    axes[0, 0].grid(True, alpha=0.3)

    axes[0, 1].plot(t[is_rd], y1_exact_np(t[is_rd]), "k-", lw=2, label=r"$y_1^*$")
    axes[0, 1].plot(t[is_rd], rec["y1"][is_rd], "r--", lw=1.5, label=r"$y_{1,\theta}$")
    axes[0, 1].plot(t[is_rd], y2_exact_np(t[is_rd]), "b-", lw=2, label=r"$y_2^*$")
    axes[0, 1].plot(t[is_rd], rec["y2"][is_rd], "g--", lw=1.5, label=r"$y_{2,\theta}$")
    axes[0, 1].plot(t[~is_rd], rec["y1"][~is_rd], "ro", ms=6)
    axes[0, 1].plot(t[~is_rd], rec["y2"][~is_rd], "gs", ms=6)
    axes[0, 1].plot(t[~is_rd], y1_exact_np(t[~is_rd]), "k+", ms=8)
    axes[0, 1].plot(t[~is_rd], y2_exact_np(t[~is_rd]), "k+", ms=8)
    axes[0, 1].set_title(
        rf"Solutions  $y_1$: {metrics['y1_err']:.3%},  $y_2$: {metrics['y2_err']:.3%}"
    )
    axes[0, 1].legend(fontsize=8)
    axes[0, 1].grid(True, alpha=0.3)

    axes[1, 0].plot(t[mask], a_exact_np(t[mask]), "k-", lw=2, label=r"$a^*$")
    axes[1, 0].plot(t[mask], rec["a"][mask], "r--", lw=1.5, label=r"$a$ (local LS)")
    axes[1, 0].plot(t[mask], b_exact_np(t[mask]), "b-", lw=2, label=r"$b^*$")
    axes[1, 0].plot(t[mask], rec["b"][mask], "g--", lw=1.5, label=r"$b$ (local LS)")
    axes[1, 0].set_title(
        rf"Local-LS recovery  $a$: {metrics['a_err']:.2%},  $b$: {metrics['b_err']:.2%}"
    )
    axes[1, 0].legend(fontsize=8)
    axes[1, 0].grid(True, alpha=0.3)

    axes[1, 1].axis("off")
    txt = (
        "V28 diagnostics (dense grain)\n"
        "─────────────────────────────────\n"
        f"  y1 rel L2     = {metrics['y1_err']:.4%}\n"
        f"  y2 rel L2     = {metrics['y2_err']:.4%}\n"
        f"  y1_dd rel L2  = {metrics['y1_dd_err']:.4%}\n"
        f"  y2_dd rel L2  = {metrics['y2_dd_err']:.4%}\n"
        f"  a (local LS)  = {metrics['a_err']:.4%}\n"
        f"  b (local LS)  = {metrics['b_err']:.4%}\n"
        "\n"
        "Determinant / conditioning\n"
        "─────────────────────────────────\n"
        f"  min |Δ|       = {metrics['delta_min']:.4e}\n"
        f"  max |Δ|       = {metrics['delta_max']:.4e}\n"
        f"  med |Δ|       = {metrics['delta_med']:.4e}\n"
        f"  cond min/med/max = "
        f"{metrics['cond_min']:.1f} / {metrics['cond_med']:.1f} / {metrics['cond_max']:.1f}\n"
        "\n"
        "Pipeline: train y only → freeze →\n"
        "smooth y^{ΔΔ} (spline) → local LS\n"
        "Cramer → Tikhonov smooth a,b.\n"
        "No free coefficient networks.\n"
        "\n"
        "Note: a_θ = a + O(|e_y|) + O(|e_{yy}|)\n"
        "(theorem assumes exact y)."
    )
    axes[1, 1].text(
        0.04, 0.97, txt, transform=axes[1, 1].transAxes, fontsize=9.5,
        family="monospace", va="top",
        bbox=dict(boxstyle="round", facecolor="whitesmoke", edgecolor="0.7"),
    )

    fig.suptitle(
        r"V28 – Stabilised Hilger inverse "
        r"(local LS + smoothed $y^{\Delta\Delta}$)",
        fontsize=12,
    )
    fig.tight_layout()
    path = os.path.join(OUTDIR, out_name)
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"\nSaved figure → {path}")
    return path


def main():
    print(f"device = {device}")
    print(
        "\nApproximation statement:\n"
        "  Theorem assumes exact y₁,y₂. PINN yields y_{i,θ}=y_i+e_i, hence\n"
        "  a_θ = a + O(‖e‖) + O(‖e^{ΔΔ}‖).  We stabilise e^{ΔΔ} by spline\n"
        "  smoothing + local least squares (not free a_θ networks).\n"
    )
    verify_exact_local_ls()

    # Primary high-quality run
    print("=" * 70)
    print("PRIMARY RUN  (noise=0.5%, seed=42, full epochs)")
    print("=" * 70)
    primary = run_once(noise=0.005, seed=42, epochs_adam=10000, epochs_lbfgs=500, verbose=True)
    m = {k: v for k, v in primary.items() if k not in ("rec", "Y1", "Y2", "loss_hist")}
    print("\n" + "=" * 70)
    print("PRIMARY RESULTS")
    print("=" * 70)
    for k, v in m.items():
        if "err" in k:
            print(f"  {k:12s} = {v:.4%}")
        else:
            print(f"  {k:12s} = {v:.6g}")
    plot_results(primary, "hilger_v28_results.png")

    with open(os.path.join(OUTDIR, "metrics_v28.txt"), "w") as fh:
        for k, v in m.items():
            fh.write(f"{k}={v}\n")

    # Multi-seed (slightly shorter for runtime)
    multi_seed_study(seeds=(0, 1, 2, 3, 4), noise=0.005, epochs_adam=6000, epochs_lbfgs=300)

    # Noise study
    noise_study(
        noise_levels=(0.0, 0.01, 0.03, 0.05, 0.10),
        seed=0, epochs_adam=6000, epochs_lbfgs=300,
    )

    print("\nV28 complete.")
    return primary


if __name__ == "__main__":
    main()
